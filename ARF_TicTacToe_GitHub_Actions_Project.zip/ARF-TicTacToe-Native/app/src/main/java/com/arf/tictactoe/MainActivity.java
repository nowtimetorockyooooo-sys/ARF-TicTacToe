package com.arf.tictactoe;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.*;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(17,16,24)); setContentView(new GameView(this)); }

    static class GameView extends View {
        Paint p = new Paint(3); Bitmap bg; int[] board = new int[9]; int turn=1; int xScore=0,oScore=0; boolean over=false; RectF newBtn=new RectF();
        int W,H; float cell, left, top;
        GameView(Context c){ super(c); bg=BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("background","drawable",c.getPackageName())); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); setFocusable(true); }
        protected void onDraw(Canvas c){ super.onDraw(c); W=getWidth(); H=getHeight();
            p.setShader(new BitmapShader(bg,Shader.TileMode.CLAMP,Shader.TileMode.CLAMP)); c.drawRect(0,0,W,H,p); p.setShader(null);
            p.setColor(0xB80A0A12); c.drawRect(0,0,W,H,p);
            p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(Math.max(28,W*.075f)); p.setColor(Color.WHITE); c.drawText("TIC TAC TOE",W/2f,65,p);
            p.setTextSize(15); p.setColor(0xFFE0E0E0); c.drawText("2 PLAYERS • SAME DEVICE",W/2f,92,p);
            p.setTextSize(18); p.setColor(0xFFFFB74D); c.drawText("❌  "+xScore,W*.28f,130,p); p.setColor(0xFF64B5F6); c.drawText("⭕  "+oScore,W*.72f,130,p);
            float size=Math.min(W*.84f, H*.48f); left=(W-size)/2; top=155; cell=size/3f;
            p.setColor(0xD91C1C28); c.drawRoundRect(left-8,top-8,left+size+8,top+size+8,22,22,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(0xFFB39DDB); for(int i=1;i<3;i++){ c.drawLine(left+i*cell,top,left+i*cell,top+size,p); c.drawLine(left,top+i*cell,left+size,top+i*cell,p);} p.setStyle(Paint.Style.FILL);
            p.setTextSize(cell*.48f); for(int i=0;i<9;i++){ if(board[i]!=0){ float cx=left+(i%3+.5f)*cell, cy=top+(i/3+.72f)*cell; p.setColor(board[i]==1?0xFFFFB74D:0xFF64B5F6); c.drawText(board[i]==1?"X":"O",cx,cy,p); }}
            p.setColor(0xEE7C4DFF); newBtn.set(W*.23f,H-105,W*.77f,H-45); c.drawRoundRect(newBtn,24,24,p); p.setColor(Color.WHITE); p.setTextSize(17); c.drawText(over?"NEW ROUND":"RESET GAME",W/2f,H-72,p);
            p.setTextSize(14); p.setColor(0xFFE0E0E0); c.drawText(over?"Tap NEW ROUND to play again":("Player "+(turn==1?"1 (X)":"2 (O)")+"'s turn"),W/2f,H-125,p);
        }
        public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_UP)return true; float x=e.getX(),y=e.getY(); if(newBtn.contains(x,y)){ java.util.Arrays.fill(board,0); turn=1; over=false; invalidate(); return true; } if(over)return true; if(x<left||x>left+cell*3||y<top||y>top+cell*3)return true; int col=(int)((x-left)/cell),row=(int)((y-top)/cell),i=row*3+col; if(board[i]!=0)return true; board[i]=turn; if(win(turn)){ if(turn==1)xScore++;else oScore++; over=true; Toast.makeText(getContext(),"Player "+turn+" wins!",Toast.LENGTH_SHORT).show(); } else if(full()){over=true;Toast.makeText(getContext(),"Draw!",Toast.LENGTH_SHORT).show();} else turn=3-turn; invalidate(); return true; }
        boolean full(){for(int v:board)if(v==0)return false;return true;} boolean win(int a){int[][] q={{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};for(int[] r:q)if(board[r[0]]==a&&board[r[1]]==a&&board[r[2]]==a)return true;return false;}
    }
}
